function About(){
    return(
        <div>
            <div>
            <h2>Company Details</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat eveniet, repellendus 
                deleniti explicabo blanditiis porro reprehenderit fugiat numquam optio,
                 soluta necessitatibus, dignissimos iure quos modi? Iure rem similique ullam nihil?</p>
            </div>
            <div>
                <h4>Project Details</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae, ipsa optio eos te
                    mporibus fugit quidem sed libero vero accusantium, ipsum velit sequi laudantium earum voluptatum ex
                    pedita sapiente amet sunt! Quisquam.</p>
            </div>
            <div>
                <h4>Team Members</h4>
                <ul>
                    <li>Rajesh </li>
                    <li>Ramesh</li>
                    <li>Akbar</li>
                </ul>
            </div>

            
        </div>
    )

}
export default About
import classes from './Welcome.module.css'
function Welcome(){
    return (
        <div className={classes.div}>
            <h1 >Welcome to Shop-Cart</h1>
            
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nisi quidem
                 quis eaque aliquam, dolor dolores provident eum 
                assumenda hic. Laudantium eum iste consequatur culpa fugiat facere cum possimus magnam atque!
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nisi quidem
                 quis eaque aliquam, dolor dolores provident eum 
                assumenda hic. Laudantium eum iste consequatur culpa fugiat facere cum possimus magnam atque!
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nisi quidem
                 quis eaque aliquam, dolor dolores provident eum 
                assumenda hic. Laudantium eum iste consequatur culpa fugiat facere cum possimus magnam atque!</p>
        </div>
    )

}
export default Welcome;